
#include <stdio.h>
#include <fcntl.h>
#include <io.h>
#include <fcntl.h>
#include <string.h>

static char *szName = {"this is a long filename"};

int main() {
	char imask;
	int file;
	char buffer[20];

	if ( ( file = _open( szName, _O_RDONLY, 0 ) ) != -1 ) {
		_asm int 3;
		printf("open ok, file=%d\n", file);
		memset( buffer, 0, sizeof( buffer ) );
		_read( file, buffer, sizeof(buffer)-1 );
		_close( file );
		printf("open(%s) ok, read=>%s<\n", szName, buffer );
	} else
		printf("open(%s) failed\n", szName );

	return 0;
}
