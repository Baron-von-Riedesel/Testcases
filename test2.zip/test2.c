#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
    int i, result;
    char buf[256];
    if (argc < 2) {
        printf("Usage: test2.exe progname args...\n");
        exit(1);
    }
    strcpy(buf, argv[1]);
    for (i = 2; i < argc; i++) {
        strcat(buf, " ");
        strcat(buf, argv[i]);
    }
    result = system(buf);
    exit(result);
}

